import { randomUUID } from "crypto";

// Project metadata for in-memory storage
export interface ProjectMetadata {
  id: string;
  name: string;
  aspectRatio: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface IStorage {
  createProject(name: string): Promise<ProjectMetadata>;
  getProject(id: string): Promise<ProjectMetadata | undefined>;
  updateProject(id: string, updates: Partial<ProjectMetadata>): Promise<ProjectMetadata | undefined>;
  listProjects(): Promise<ProjectMetadata[]>;
  deleteProject(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private projects: Map<string, ProjectMetadata>;

  constructor() {
    this.projects = new Map();
  }

  async createProject(name: string): Promise<ProjectMetadata> {
    const id = randomUUID();
    const now = new Date();
    const project: ProjectMetadata = {
      id,
      name,
      aspectRatio: "16:9",
      createdAt: now,
      updatedAt: now,
    };
    this.projects.set(id, project);
    return project;
  }

  async getProject(id: string): Promise<ProjectMetadata | undefined> {
    return this.projects.get(id);
  }

  async updateProject(id: string, updates: Partial<ProjectMetadata>): Promise<ProjectMetadata | undefined> {
    const project = this.projects.get(id);
    if (!project) return undefined;
    
    const updatedProject = {
      ...project,
      ...updates,
      updatedAt: new Date(),
    };
    this.projects.set(id, updatedProject);
    return updatedProject;
  }

  async listProjects(): Promise<ProjectMetadata[]> {
    return Array.from(this.projects.values()).sort(
      (a, b) => b.updatedAt.getTime() - a.updatedAt.getTime()
    );
  }

  async deleteProject(id: string): Promise<boolean> {
    return this.projects.delete(id);
  }
}

export const storage = new MemStorage();
