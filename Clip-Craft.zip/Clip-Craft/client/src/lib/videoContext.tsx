import { createContext, useContext, useState, useCallback, useRef, type ReactNode } from "react";
import { v4 as uuidv4 } from "uuid";
import type { VideoClip, TimelineClip, Project } from "@shared/schema";
import { filterPresets } from "@shared/schema";

interface VideoContextType {
  project: Project;
  currentTime: number;
  isPlaying: boolean;
  selectedClipId: string | null;
  activeFilter: string;
  adjustments: {
    brightness: number;
    contrast: number;
    saturation: number;
  };
  addClip: (file: File) => Promise<void>;
  removeClip: (clipId: string) => void;
  addToTimeline: (clip: VideoClip) => void;
  removeFromTimeline: (timelineClipId: string) => void;
  updateTimelineClip: (id: string, updates: Partial<TimelineClip>) => void;
  setCurrentTime: (time: number) => void;
  play: () => void;
  pause: () => void;
  togglePlay: () => void;
  setAspectRatio: (ratio: "16:9" | "9:16" | "1:1" | "4:5") => void;
  selectClip: (clipId: string | null) => void;
  setActiveFilter: (filterId: string) => void;
  setAdjustments: (adjustments: { brightness: number; contrast: number; saturation: number }) => void;
  getTotalDuration: () => number;
  getClipById: (id: string) => VideoClip | undefined;
  reorderTimeline: (fromIndex: number, toIndex: number) => void;
  videoRef: React.RefObject<HTMLVideoElement | null>;
  clipEffects: Map<string, { filter: string; adjustments: { brightness: number; contrast: number; saturation: number } }>;
}

const VideoContext = createContext<VideoContextType | null>(null);

export function VideoProvider({ children }: { children: ReactNode }) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  
  const [project, setProject] = useState<Project>({
    id: uuidv4(),
    name: "Untitled Project",
    aspectRatio: "16:9",
    clips: [],
    timeline: [],
    effects: [],
  });

  const [currentTime, setCurrentTimeState] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [selectedClipId, setSelectedClipId] = useState<string | null>(null);
  const [activeFilter, setActiveFilterState] = useState("none");
  const [adjustments, setAdjustmentsState] = useState({
    brightness: 100,
    contrast: 100,
    saturation: 100,
  });
  const [clipEffects, setClipEffects] = useState<Map<string, { filter: string; adjustments: { brightness: number; contrast: number; saturation: number } }>>(new Map());

  const addClip = useCallback(async (file: File) => {
    const url = URL.createObjectURL(file);
    
    const video = document.createElement("video");
    video.preload = "metadata";
    
    await new Promise<void>((resolve) => {
      video.onloadedmetadata = () => resolve();
      video.src = url;
    });

    const canvas = document.createElement("canvas");
    canvas.width = 160;
    canvas.height = 90;
    const ctx = canvas.getContext("2d");
    
    await new Promise<void>((resolve) => {
      video.onseeked = () => {
        if (ctx) {
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        }
        resolve();
      };
      video.currentTime = 1;
    });

    const thumbnailUrl = canvas.toDataURL("image/jpeg", 0.7);

    const newClip: VideoClip = {
      id: uuidv4(),
      name: file.name,
      file,
      url,
      thumbnailUrl,
      duration: video.duration,
      width: video.videoWidth,
      height: video.videoHeight,
      type: file.type,
      size: file.size,
    };

    setProject((prev) => ({
      ...prev,
      clips: [...prev.clips, newClip],
    }));
  }, []);

  const removeClip = useCallback((clipId: string) => {
    setProject((prev) => ({
      ...prev,
      clips: prev.clips.filter((c) => c.id !== clipId),
      timeline: prev.timeline.filter((t) => t.clipId !== clipId),
    }));
  }, []);

  const addToTimeline = useCallback((clip: VideoClip) => {
    setProject((prev) => {
      const lastEndTime = prev.timeline.reduce((max, t) => {
        return Math.max(max, t.endTime);
      }, 0);

      const clipDuration = clip.duration;
      const newTimelineClip: TimelineClip = {
        id: uuidv4(),
        clipId: clip.id,
        startTime: lastEndTime,
        endTime: lastEndTime + clipDuration,
        trimStart: 0,
        trimEnd: clipDuration,
        track: 0,
      };

      return {
        ...prev,
        timeline: [...prev.timeline, newTimelineClip],
      };
    });
  }, []);

  const removeFromTimeline = useCallback((timelineClipId: string) => {
    setProject((prev) => ({
      ...prev,
      timeline: prev.timeline.filter((t) => t.id !== timelineClipId),
    }));
  }, []);

  const updateTimelineClip = useCallback((id: string, updates: Partial<TimelineClip>) => {
    setProject((prev) => ({
      ...prev,
      timeline: prev.timeline.map((t) =>
        t.id === id ? { ...t, ...updates } : t
      ),
    }));
  }, []);

  const setCurrentTime = useCallback((time: number) => {
    setCurrentTimeState(time);
    if (videoRef.current) {
      videoRef.current.currentTime = time;
    }
  }, []);

  const play = useCallback(() => {
    setIsPlaying(true);
    videoRef.current?.play();
  }, []);

  const pause = useCallback(() => {
    setIsPlaying(false);
    videoRef.current?.pause();
  }, []);

  const togglePlay = useCallback(() => {
    if (isPlaying) {
      pause();
    } else {
      play();
    }
  }, [isPlaying, play, pause]);

  const setAspectRatio = useCallback((ratio: "16:9" | "9:16" | "1:1" | "4:5") => {
    setProject((prev) => ({ ...prev, aspectRatio: ratio }));
  }, []);

  const selectClip = useCallback((clipId: string | null) => {
    setSelectedClipId(clipId);
  }, []);

  const setActiveFilter = useCallback((filterId: string) => {
    setActiveFilterState(filterId);
    if (selectedClipId) {
      setClipEffects((prev) => {
        const newMap = new Map(prev);
        const existing = newMap.get(selectedClipId) || { filter: filterId, adjustments };
        newMap.set(selectedClipId, { ...existing, filter: filterId });
        return newMap;
      });
    }
  }, [selectedClipId, adjustments]);

  const setAdjustments = useCallback((newAdjustments: { brightness: number; contrast: number; saturation: number }) => {
    setAdjustmentsState(newAdjustments);
    if (selectedClipId) {
      setClipEffects((prev) => {
        const newMap = new Map(prev);
        const existing = newMap.get(selectedClipId) || { filter: activeFilter, adjustments: newAdjustments };
        newMap.set(selectedClipId, { ...existing, adjustments: newAdjustments });
        return newMap;
      });
    }
  }, [selectedClipId, activeFilter]);

  const getTotalDuration = useCallback(() => {
    return project.timeline.reduce((max, t) => {
      return Math.max(max, t.endTime);
    }, 0);
  }, [project.timeline]);

  const getClipById = useCallback((id: string) => {
    return project.clips.find((c) => c.id === id);
  }, [project.clips]);

  const reorderTimeline = useCallback((fromIndex: number, toIndex: number) => {
    setProject((prev) => {
      const timeline = [...prev.timeline];
      const [removed] = timeline.splice(fromIndex, 1);
      timeline.splice(toIndex, 0, removed);
      
      let currentStart = 0;
      const reorderedTimeline = timeline.map((clip) => {
        const duration = clip.endTime - clip.startTime;
        const newClip = {
          ...clip,
          startTime: currentStart,
          endTime: currentStart + duration,
        };
        currentStart += duration;
        return newClip;
      });
      
      return { ...prev, timeline: reorderedTimeline };
    });
  }, []);

  return (
    <VideoContext.Provider
      value={{
        project,
        currentTime,
        isPlaying,
        selectedClipId,
        activeFilter,
        adjustments,
        addClip,
        removeClip,
        addToTimeline,
        removeFromTimeline,
        updateTimelineClip,
        setCurrentTime,
        play,
        pause,
        togglePlay,
        setAspectRatio,
        selectClip,
        setActiveFilter,
        setAdjustments,
        getTotalDuration,
        getClipById,
        reorderTimeline,
        videoRef,
        clipEffects,
      }}
    >
      {children}
    </VideoContext.Provider>
  );
}

export function useVideo() {
  const context = useContext(VideoContext);
  if (!context) {
    throw new Error("useVideo must be used within a VideoProvider");
  }
  return context;
}
