import { useVideo } from "@/lib/videoContext";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Smartphone, Monitor, Square, RectangleVertical } from "lucide-react";

const aspectRatios = [
  { id: "16:9", label: "16:9", sublabel: "YouTube", icon: Monitor },
  { id: "9:16", label: "9:16", sublabel: "TikTok/Reels", icon: Smartphone },
  { id: "1:1", label: "1:1", sublabel: "Instagram", icon: Square },
  { id: "4:5", label: "4:5", sublabel: "Portrait", icon: RectangleVertical },
] as const;

export function AspectRatioSelector() {
  const { project, setAspectRatio } = useVideo();

  return (
    <div className="flex items-center gap-1 p-1 bg-card rounded-lg border border-border">
      {aspectRatios.map(({ id, label, sublabel, icon: Icon }) => (
        <Button
          key={id}
          variant={project.aspectRatio === id ? "default" : "ghost"}
          size="sm"
          onClick={() => setAspectRatio(id)}
          className={cn(
            "flex flex-col h-auto py-1 px-2 gap-0",
            project.aspectRatio === id && "bg-primary text-primary-foreground"
          )}
          data-testid={`button-aspect-${id.replace(":", "-")}`}
        >
          <Icon className="w-4 h-4" />
          <span className="text-[10px] font-medium mt-0.5">{label}</span>
        </Button>
      ))}
    </div>
  );
}
