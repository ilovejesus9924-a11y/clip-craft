import { useEffect, useRef, useState } from "react";
import { useVideo } from "@/lib/videoContext";
import { aspectRatioDimensions, filterPresets } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Play, Pause, SkipBack, SkipForward, Volume2, VolumeX, Maximize2 } from "lucide-react";
import { Slider } from "@/components/ui/slider";

function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  const frames = Math.floor((seconds % 1) * 30);
  return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}:${frames.toString().padStart(2, "0")}`;
}

export function VideoPreview() {
  const {
    project,
    currentTime,
    isPlaying,
    togglePlay,
    setCurrentTime,
    getTotalDuration,
    getClipById,
    activeFilter,
    adjustments,
    videoRef,
  } = useVideo();

  const containerRef = useRef<HTMLDivElement>(null);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const aspectRatio = project.aspectRatio;
  const dimensions = aspectRatioDimensions[aspectRatio];
  const aspectValue = dimensions.width / dimensions.height;

  const currentTimelineClip = project.timeline.find(
    (t) => currentTime >= t.startTime && currentTime < t.endTime
  );
  const currentClip = currentTimelineClip ? getClipById(currentTimelineClip.clipId) : null;

  const totalDuration = getTotalDuration();

  const filterStyle = filterPresets.find((f) => f.id === activeFilter)?.filter || "";
  const adjustmentStyle = `brightness(${adjustments.brightness / 100}) contrast(${adjustments.contrast / 100}) saturate(${adjustments.saturation / 100})`;

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.volume = isMuted ? 0 : volume;
    }
  }, [volume, isMuted, videoRef]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handleTimeUpdate = () => {
      if (currentTimelineClip) {
        const videoTime = video.currentTime;
        const timelineTime = currentTimelineClip.startTime + videoTime - currentTimelineClip.trimStart;
        setCurrentTime(Math.min(timelineTime, currentTimelineClip.endTime));
      }
    };

    video.addEventListener("timeupdate", handleTimeUpdate);
    return () => video.removeEventListener("timeupdate", handleTimeUpdate);
  }, [currentTimelineClip, setCurrentTime, videoRef]);

  useEffect(() => {
    if (currentTimelineClip && videoRef.current && currentClip) {
      const clipTime = currentTime - currentTimelineClip.startTime + currentTimelineClip.trimStart;
      if (Math.abs(videoRef.current.currentTime - clipTime) > 0.5) {
        videoRef.current.currentTime = clipTime;
      }
    }
  }, [currentTimelineClip, currentTime, currentClip, videoRef]);

  const handleSkipBack = () => {
    setCurrentTime(Math.max(0, currentTime - 5));
  };

  const handleSkipForward = () => {
    setCurrentTime(Math.min(totalDuration, currentTime + 5));
  };

  const handleTimelineClick = (value: number[]) => {
    setCurrentTime(value[0]);
  };

  const toggleFullscreen = () => {
    if (containerRef.current) {
      if (!document.fullscreenElement) {
        containerRef.current.requestFullscreen();
        setIsFullscreen(true);
      } else {
        document.exitFullscreen();
        setIsFullscreen(false);
      }
    }
  };

  return (
    <div className="flex flex-col h-full" ref={containerRef}>
      <div className="flex-1 flex items-center justify-center p-4 bg-black/40 rounded-lg overflow-hidden">
        <div
          className="relative bg-black rounded-md overflow-hidden"
          style={{
            aspectRatio: aspectValue,
            maxWidth: "100%",
            maxHeight: "100%",
            width: aspectValue > 1 ? "100%" : "auto",
            height: aspectValue <= 1 ? "100%" : "auto",
          }}
        >
          {currentClip ? (
            <video
              ref={videoRef as React.RefObject<HTMLVideoElement>}
              src={currentClip.url}
              className="w-full h-full object-contain"
              style={{ filter: `${filterStyle} ${adjustmentStyle}` }}
              loop={project.timeline.length === 1}
              data-testid="video-preview-player"
            />
          ) : (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-muted-foreground">
              <Play className="w-16 h-16 mb-4 opacity-30" />
              <p className="text-sm">Add media to get started</p>
            </div>
          )}
          
          <div className="absolute top-2 left-2 bg-black/60 backdrop-blur-sm px-2 py-1 rounded text-xs font-mono text-white/80" data-testid="timecode-display">
            {formatTime(currentTime)}
          </div>
        </div>
      </div>

      <div className="p-4 space-y-4 bg-card rounded-lg mt-2">
        <div className="flex items-center gap-2">
          <span className="text-xs font-mono text-muted-foreground w-16" data-testid="time-current">
            {formatTime(currentTime)}
          </span>
          <Slider
            value={[currentTime]}
            max={totalDuration || 1}
            step={0.1}
            onValueChange={handleTimelineClick}
            className="flex-1"
            data-testid="scrubber-slider"
          />
          <span className="text-xs font-mono text-muted-foreground w-16 text-right" data-testid="time-total">
            {formatTime(totalDuration)}
          </span>
        </div>

        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-1">
            <Button
              size="icon"
              variant="ghost"
              onClick={() => setIsMuted(!isMuted)}
              data-testid="button-volume-toggle"
            >
              {isMuted || volume === 0 ? (
                <VolumeX className="w-4 h-4" />
              ) : (
                <Volume2 className="w-4 h-4" />
              )}
            </Button>
            <Slider
              value={[isMuted ? 0 : volume]}
              max={1}
              step={0.1}
              onValueChange={(v) => {
                setVolume(v[0]);
                if (v[0] > 0) setIsMuted(false);
              }}
              className="w-20"
              data-testid="volume-slider"
            />
          </div>

          <div className="flex items-center gap-2">
            <Button
              size="icon"
              variant="ghost"
              onClick={handleSkipBack}
              data-testid="button-skip-back"
            >
              <SkipBack className="w-4 h-4" />
            </Button>
            <Button
              size="icon"
              variant="default"
              onClick={togglePlay}
              className="w-12 h-12 rounded-full"
              data-testid="button-play-pause"
            >
              {isPlaying ? (
                <Pause className="w-5 h-5" />
              ) : (
                <Play className="w-5 h-5 ml-0.5" />
              )}
            </Button>
            <Button
              size="icon"
              variant="ghost"
              onClick={handleSkipForward}
              data-testid="button-skip-forward"
            >
              <SkipForward className="w-4 h-4" />
            </Button>
          </div>

          <Button
            size="icon"
            variant="ghost"
            onClick={toggleFullscreen}
            data-testid="button-fullscreen"
          >
            <Maximize2 className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
