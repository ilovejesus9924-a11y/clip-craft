import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Card } from "@/components/ui/card";
import { Download, Loader2, Check, Film, Sparkles } from "lucide-react";
import { useVideo } from "@/lib/videoContext";
import { cn } from "@/lib/utils";
import type { ExportSettings } from "@shared/schema";

const qualityOptions = [
  {
    id: "1080p",
    label: "1080p",
    sublabel: "Full HD",
    description: "Best quality for most uses",
  },
  {
    id: "720p",
    label: "720p",
    sublabel: "HD",
    description: "Good balance of quality and size",
  },
  {
    id: "480p",
    label: "480p",
    sublabel: "SD",
    description: "Smaller file size, lower quality",
  },
] as const;

export function ExportModal() {
  const { project, getTotalDuration, getClipById, activeFilter, adjustments } = useVideo();
  const [isOpen, setIsOpen] = useState(false);
  const [settings, setSettings] = useState<ExportSettings>({
    quality: "1080p",
    format: "mp4",
  });
  const [isExporting, setIsExporting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [isComplete, setIsComplete] = useState(false);
  const [exportedUrl, setExportedUrl] = useState<string | null>(null);

  const hasClips = project.timeline.length > 0;
  const totalDuration = getTotalDuration();

  const handleExport = async () => {
    if (!hasClips) return;

    setIsExporting(true);
    setProgress(0);
    setIsComplete(false);

    try {
      // Simulate export progress (in real implementation, this would use FFmpeg.wasm)
      for (let i = 0; i <= 100; i += 5) {
        await new Promise((resolve) => setTimeout(resolve, 200));
        setProgress(i);
      }

      // For now, we'll create a blob from the first video clip
      // In a real implementation, this would be the processed video
      const firstTimelineClip = project.timeline[0];
      if (firstTimelineClip) {
        const clip = getClipById(firstTimelineClip.clipId);
        if (clip?.file) {
          const url = URL.createObjectURL(clip.file);
          setExportedUrl(url);
        }
      }

      setIsComplete(true);
    } catch (error) {
      console.error("Export failed:", error);
    } finally {
      setIsExporting(false);
    }
  };

  const handleDownload = () => {
    if (exportedUrl) {
      const a = document.createElement("a");
      a.href = exportedUrl;
      a.download = `${project.name}.${settings.format}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }
  };

  const handleClose = () => {
    setIsOpen(false);
    setProgress(0);
    setIsComplete(false);
    setExportedUrl(null);
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button
          disabled={!hasClips}
          className="gap-2"
          data-testid="button-export"
        >
          <Download className="w-4 h-4" />
          Export
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md" onPointerDownOutside={(e) => isExporting && e.preventDefault()}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            Export Video
          </DialogTitle>
          <DialogDescription>
            Choose your export settings and download your video.
          </DialogDescription>
        </DialogHeader>

        {!isExporting && !isComplete ? (
          <div className="space-y-4">
            <div>
              <h4 className="text-sm font-medium mb-3">Quality</h4>
              <div className="grid gap-2">
                {qualityOptions.map((option) => (
                  <Card
                    key={option.id}
                    className={cn(
                      "p-3 cursor-pointer transition-all hover-elevate",
                      settings.quality === option.id
                        ? "border-primary ring-2 ring-primary/30"
                        : "border-border"
                    )}
                    onClick={() => setSettings({ ...settings, quality: option.id })}
                    data-testid={`quality-${option.id}`}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-sm">
                          {option.label}{" "}
                          <span className="text-muted-foreground font-normal">
                            {option.sublabel}
                          </span>
                        </p>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          {option.description}
                        </p>
                      </div>
                      {settings.quality === option.id && (
                        <Check className="w-4 h-4 text-primary" />
                      )}
                    </div>
                  </Card>
                ))}
              </div>
            </div>

            <div className="pt-2 border-t border-border">
              <div className="flex items-center justify-between text-sm text-muted-foreground mb-4">
                <span>Duration: {Math.ceil(totalDuration)}s</span>
                <span>Format: MP4</span>
              </div>
              <Button
                className="w-full"
                onClick={handleExport}
                data-testid="button-start-export"
              >
                <Film className="w-4 h-4 mr-2" />
                Start Export
              </Button>
            </div>
          </div>
        ) : isExporting ? (
          <div className="py-6 space-y-4">
            <div className="flex flex-col items-center gap-4">
              <Loader2 className="w-10 h-10 animate-spin text-primary" />
              <div className="text-center">
                <p className="font-medium">Exporting your video...</p>
                <p className="text-sm text-muted-foreground mt-1">
                  This may take a moment
                </p>
              </div>
            </div>
            <Progress value={progress} className="w-full" />
            <p className="text-center text-sm text-muted-foreground">
              {progress}% complete
            </p>
          </div>
        ) : (
          <div className="py-6 space-y-4">
            <div className="flex flex-col items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
                <Check className="w-8 h-8 text-primary" />
              </div>
              <div className="text-center">
                <p className="font-medium">Export Complete!</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Your video is ready to download
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                className="flex-1"
                onClick={handleClose}
                data-testid="button-close-export"
              >
                Close
              </Button>
              <Button
                className="flex-1"
                onClick={handleDownload}
                data-testid="button-download"
              >
                <Download className="w-4 h-4 mr-2" />
                Download
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
