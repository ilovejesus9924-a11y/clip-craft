import { useVideo } from "@/lib/videoContext";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { filterPresets } from "@shared/schema";
import { Sparkles, SlidersHorizontal, RotateCcw } from "lucide-react";
import { cn } from "@/lib/utils";

export function EffectsPanel() {
  const { activeFilter, setActiveFilter, adjustments, setAdjustments } = useVideo();

  const handleResetAdjustments = () => {
    setAdjustments({
      brightness: 100,
      contrast: 100,
      saturation: 100,
    });
  };

  return (
    <div className="h-full flex flex-col">
      <Tabs defaultValue="filters" className="flex-1 flex flex-col">
        <div className="border-b border-border">
          <TabsList className="w-full h-auto p-1 bg-transparent justify-start gap-1">
            <TabsTrigger
              value="filters"
              className="text-xs data-[state=active]:bg-accent"
              data-testid="tab-filters"
            >
              <Sparkles className="w-3 h-3 mr-1" />
              Filters
            </TabsTrigger>
            <TabsTrigger
              value="adjust"
              className="text-xs data-[state=active]:bg-accent"
              data-testid="tab-adjust"
            >
              <SlidersHorizontal className="w-3 h-3 mr-1" />
              Adjust
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="filters" className="flex-1 m-0 p-0">
          <ScrollArea className="h-full">
            <div className="p-4">
              <h3 className="text-sm font-medium mb-3">Filter Presets</h3>
              <div className="grid grid-cols-2 gap-2">
                {filterPresets.map((filter) => (
                  <button
                    key={filter.id}
                    onClick={() => setActiveFilter(filter.id)}
                    className={cn(
                      "relative rounded-lg overflow-hidden aspect-video border-2 transition-all hover-elevate",
                      activeFilter === filter.id
                        ? "border-primary ring-2 ring-primary/30"
                        : "border-transparent"
                    )}
                    data-testid={`filter-${filter.id}`}
                  >
                    <div
                      className="absolute inset-0 bg-gradient-to-br from-primary/40 via-accent/30 to-secondary/40"
                      style={{ filter: filter.filter }}
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-xs font-medium text-foreground bg-background/80 px-2 py-1 rounded">
                        {filter.name}
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </ScrollArea>
        </TabsContent>

        <TabsContent value="adjust" className="flex-1 m-0 p-0">
          <ScrollArea className="h-full">
            <div className="p-4 space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-medium">Color Adjustments</h3>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleResetAdjustments}
                  data-testid="button-reset-adjustments"
                >
                  <RotateCcw className="w-3 h-3 mr-1" />
                  Reset
                </Button>
              </div>

              <div className="space-y-5">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label className="text-xs text-muted-foreground">Brightness</Label>
                    <span className="text-xs font-mono text-muted-foreground">
                      {adjustments.brightness}%
                    </span>
                  </div>
                  <Slider
                    value={[adjustments.brightness]}
                    min={0}
                    max={200}
                    step={1}
                    onValueChange={(v) =>
                      setAdjustments({ ...adjustments, brightness: v[0] })
                    }
                    data-testid="slider-brightness"
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label className="text-xs text-muted-foreground">Contrast</Label>
                    <span className="text-xs font-mono text-muted-foreground">
                      {adjustments.contrast}%
                    </span>
                  </div>
                  <Slider
                    value={[adjustments.contrast]}
                    min={0}
                    max={200}
                    step={1}
                    onValueChange={(v) =>
                      setAdjustments({ ...adjustments, contrast: v[0] })
                    }
                    data-testid="slider-contrast"
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label className="text-xs text-muted-foreground">Saturation</Label>
                    <span className="text-xs font-mono text-muted-foreground">
                      {adjustments.saturation}%
                    </span>
                  </div>
                  <Slider
                    value={[adjustments.saturation]}
                    min={0}
                    max={200}
                    step={1}
                    onValueChange={(v) =>
                      setAdjustments({ ...adjustments, saturation: v[0] })
                    }
                    data-testid="slider-saturation"
                  />
                </div>
              </div>
            </div>
          </ScrollArea>
        </TabsContent>
      </Tabs>
    </div>
  );
}
