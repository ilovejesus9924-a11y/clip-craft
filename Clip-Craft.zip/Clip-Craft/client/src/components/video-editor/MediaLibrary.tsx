import { useCallback, useState } from "react";
import { useVideo } from "@/lib/videoContext";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Upload, Film, Trash2, Plus, FileVideo, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";

function formatDuration(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs.toString().padStart(2, "0")}`;
}

function formatFileSize(bytes: number): string {
  if (bytes < 1024 * 1024) {
    return `${(bytes / 1024).toFixed(1)} KB`;
  }
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function MediaLibrary() {
  const { project, addClip, removeClip, addToTimeline } = useVideo();
  const [isDragOver, setIsDragOver] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleFileSelect = useCallback(
    async (files: FileList | null) => {
      if (!files) return;

      setIsLoading(true);
      const validTypes = ["video/mp4", "video/webm", "video/quicktime", "video/x-msvideo"];

      for (const file of Array.from(files)) {
        if (validTypes.includes(file.type)) {
          await addClip(file);
        }
      }
      setIsLoading(false);
    },
    [addClip]
  );

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragOver(false);
      handleFileSelect(e.dataTransfer.files);
    },
    [handleFileSelect]
  );

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = () => {
    setIsDragOver(false);
  };

  return (
    <div className="h-full flex flex-col">
      <div className="p-4 border-b border-border">
        <h2 className="text-sm font-semibold flex items-center gap-2 mb-3">
          <Film className="w-4 h-4" />
          Media Library
        </h2>

        <div
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          className={cn(
            "relative border-2 border-dashed rounded-lg p-6 text-center transition-colors",
            isDragOver
              ? "border-primary bg-primary/10"
              : "border-border hover:border-muted-foreground/50"
          )}
        >
          <input
            type="file"
            accept="video/*"
            multiple
            onChange={(e) => handleFileSelect(e.target.files)}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            data-testid="input-file-upload"
          />
          
          {isLoading ? (
            <div className="flex flex-col items-center gap-2">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
              <p className="text-sm text-muted-foreground">Processing video...</p>
            </div>
          ) : (
            <>
              <Upload className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
              <p className="text-sm font-medium">Drop videos here</p>
              <p className="text-xs text-muted-foreground mt-1">
                MP4, MOV, AVI, WebM
              </p>
            </>
          )}
        </div>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-4 space-y-2">
          {project.clips.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <FileVideo className="w-12 h-12 mx-auto mb-3 opacity-30" />
              <p className="text-sm">No media yet</p>
              <p className="text-xs mt-1">Upload videos to get started</p>
            </div>
          ) : (
            project.clips.map((clip) => (
              <Card
                key={clip.id}
                className="overflow-hidden hover-elevate cursor-pointer group"
                data-testid={`media-clip-${clip.id}`}
              >
                <div className="flex gap-3 p-2">
                  <div className="relative w-20 h-12 bg-black rounded overflow-hidden flex-shrink-0">
                    {clip.thumbnailUrl ? (
                      <img
                        src={clip.thumbnailUrl}
                        alt={clip.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <FileVideo className="w-6 h-6 text-muted-foreground" />
                      </div>
                    )}
                    <Badge
                      variant="secondary"
                      className="absolute bottom-1 right-1 text-[10px] px-1 py-0"
                    >
                      {formatDuration(clip.duration)}
                    </Badge>
                  </div>

                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate" title={clip.name}>
                      {clip.name}
                    </p>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {clip.width}x{clip.height} • {formatFileSize(clip.size)}
                    </p>
                  </div>
                </div>

                <div className="flex border-t border-border">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="flex-1 rounded-none h-8"
                    onClick={() => addToTimeline(clip)}
                    data-testid={`button-add-to-timeline-${clip.id}`}
                  >
                    <Plus className="w-3 h-3 mr-1" />
                    Add
                  </Button>
                  <div className="w-px bg-border" />
                  <Button
                    variant="ghost"
                    size="sm"
                    className="flex-1 rounded-none h-8 text-destructive hover:text-destructive"
                    onClick={() => removeClip(clip.id)}
                    data-testid={`button-remove-clip-${clip.id}`}
                  >
                    <Trash2 className="w-3 h-3 mr-1" />
                    Remove
                  </Button>
                </div>
              </Card>
            ))
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
