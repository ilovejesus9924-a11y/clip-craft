import { useRef, useState, useCallback, useEffect } from "react";
import { useVideo } from "@/lib/videoContext";
import { Button } from "@/components/ui/button";
import { Scissors, Trash2, ZoomIn, ZoomOut, GripVertical } from "lucide-react";
import { cn } from "@/lib/utils";

const MIN_ZOOM = 20;
const MAX_ZOOM = 200;

export function Timeline() {
  const {
    project,
    currentTime,
    setCurrentTime,
    getTotalDuration,
    getClipById,
    removeFromTimeline,
    updateTimelineClip,
    selectedClipId,
    selectClip,
    reorderTimeline,
  } = useVideo();

  const timelineRef = useRef<HTMLDivElement>(null);
  const [zoom, setZoom] = useState(50);
  const [isDragging, setIsDragging] = useState(false);
  const [draggedClipIndex, setDraggedClipIndex] = useState<number | null>(null);
  const [dropTarget, setDropTarget] = useState<number | null>(null);

  const totalDuration = getTotalDuration() || 10;
  const pixelsPerSecond = zoom;

  const generateTimeMarkers = () => {
    const markers = [];
    const interval = zoom > 100 ? 1 : zoom > 50 ? 5 : 10;
    for (let i = 0; i <= Math.ceil(totalDuration); i += interval) {
      markers.push(i);
    }
    return markers;
  };

  const handleTimelineClick = (e: React.MouseEvent) => {
    if (!timelineRef.current || isDragging) return;
    const rect = timelineRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left + timelineRef.current.scrollLeft;
    const time = x / pixelsPerSecond;
    setCurrentTime(Math.max(0, Math.min(time, totalDuration)));
  };

  const handleDragStart = (index: number) => {
    setIsDragging(true);
    setDraggedClipIndex(index);
  };

  const handleDragOver = (e: React.DragEvent, targetIndex: number) => {
    e.preventDefault();
    if (draggedClipIndex !== null && draggedClipIndex !== targetIndex) {
      setDropTarget(targetIndex);
    }
  };

  const handleDrop = (targetIndex: number) => {
    if (draggedClipIndex !== null && draggedClipIndex !== targetIndex) {
      reorderTimeline(draggedClipIndex, targetIndex);
    }
    setIsDragging(false);
    setDraggedClipIndex(null);
    setDropTarget(null);
  };

  const handleDragEnd = () => {
    setIsDragging(false);
    setDraggedClipIndex(null);
    setDropTarget(null);
  };

  const handleSplit = () => {
    const clipAtTime = project.timeline.find(
      (t) => currentTime > t.startTime && currentTime < t.endTime
    );
    if (!clipAtTime) return;

    const splitPoint = currentTime - clipAtTime.startTime + clipAtTime.trimStart;
    
    updateTimelineClip(clipAtTime.id, {
      trimEnd: splitPoint,
      endTime: currentTime,
    });
  };

  return (
    <div className="h-full flex flex-col bg-card rounded-lg overflow-hidden">
      <div className="flex items-center justify-between gap-2 p-2 border-b border-border">
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="ghost"
            onClick={handleSplit}
            disabled={project.timeline.length === 0}
            data-testid="button-split"
          >
            <Scissors className="w-4 h-4 mr-1" />
            Split
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => selectedClipId && removeFromTimeline(selectedClipId)}
            disabled={!selectedClipId}
            data-testid="button-delete-clip"
          >
            <Trash2 className="w-4 h-4 mr-1" />
            Delete
          </Button>
        </div>

        <div className="flex items-center gap-2">
          <Button
            size="icon"
            variant="ghost"
            onClick={() => setZoom(Math.max(MIN_ZOOM, zoom - 10))}
            data-testid="button-zoom-out"
          >
            <ZoomOut className="w-4 h-4" />
          </Button>
          <span className="text-xs text-muted-foreground w-12 text-center">
            {Math.round(zoom)}%
          </span>
          <Button
            size="icon"
            variant="ghost"
            onClick={() => setZoom(Math.min(MAX_ZOOM, zoom + 10))}
            data-testid="button-zoom-in"
          >
            <ZoomIn className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <div
        ref={timelineRef}
        className="flex-1 overflow-x-auto overflow-y-hidden relative"
        onClick={handleTimelineClick}
        data-testid="timeline-container"
      >
        <div
          className="relative min-h-full"
          style={{ width: `${totalDuration * pixelsPerSecond + 100}px` }}
        >
          <div className="h-6 border-b border-border bg-muted/30 flex items-end">
            {generateTimeMarkers().map((time) => (
              <div
                key={time}
                className="absolute bottom-0 flex flex-col items-center"
                style={{ left: `${time * pixelsPerSecond}px` }}
              >
                <span className="text-[10px] text-muted-foreground font-mono mb-1">
                  {Math.floor(time / 60)}:{(time % 60).toString().padStart(2, "0")}
                </span>
                <div className="w-px h-2 bg-border" />
              </div>
            ))}
          </div>

          <div className="relative h-16 mt-2 mx-2">
            {project.timeline.length === 0 ? (
              <div className="absolute inset-0 flex items-center justify-center text-muted-foreground text-sm border-2 border-dashed border-border rounded-md">
                Drag clips here to add them to the timeline
              </div>
            ) : (
              project.timeline.map((timelineClip, index) => {
                const clip = getClipById(timelineClip.clipId);
                if (!clip) return null;

                const width = (timelineClip.endTime - timelineClip.startTime) * pixelsPerSecond;
                const left = timelineClip.startTime * pixelsPerSecond;

                return (
                  <div
                    key={timelineClip.id}
                    draggable
                    onDragStart={() => handleDragStart(index)}
                    onDragOver={(e) => handleDragOver(e, index)}
                    onDrop={() => handleDrop(index)}
                    onDragEnd={handleDragEnd}
                    onClick={(e) => {
                      e.stopPropagation();
                      selectClip(timelineClip.id);
                    }}
                    className={cn(
                      "absolute h-14 rounded-md overflow-hidden cursor-grab active:cursor-grabbing transition-all",
                      "bg-gradient-to-br from-primary/80 to-primary/60 border",
                      selectedClipId === timelineClip.id
                        ? "border-primary ring-2 ring-primary/50"
                        : "border-primary/40",
                      draggedClipIndex === index && "opacity-50",
                      dropTarget === index && "ring-2 ring-accent"
                    )}
                    style={{ left: `${left}px`, width: `${width}px` }}
                    data-testid={`timeline-clip-${timelineClip.id}`}
                  >
                    <div className="flex items-center h-full px-2 gap-2">
                      <GripVertical className="w-3 h-3 text-primary-foreground/60 flex-shrink-0" />
                      {clip.thumbnailUrl && (
                        <img
                          src={clip.thumbnailUrl}
                          alt={clip.name}
                          className="h-10 w-auto rounded object-cover flex-shrink-0"
                        />
                      )}
                      <span className="text-xs text-primary-foreground font-medium truncate">
                        {clip.name}
                      </span>
                    </div>

                    <div className="absolute left-0 top-0 bottom-0 w-1 bg-white/20 cursor-ew-resize" />
                    <div className="absolute right-0 top-0 bottom-0 w-1 bg-white/20 cursor-ew-resize" />
                  </div>
                );
              })
            )}
          </div>

          <div
            className="absolute top-0 bottom-0 w-0.5 bg-destructive z-10 pointer-events-none"
            style={{ left: `${currentTime * pixelsPerSecond}px` }}
          >
            <div className="absolute -top-1 -left-1.5 w-3.5 h-3 bg-destructive rounded-sm" />
          </div>
        </div>
      </div>
    </div>
  );
}
