import { VideoProvider } from "@/lib/videoContext";
import { VideoPreview } from "@/components/video-editor/VideoPreview";
import { Timeline } from "@/components/video-editor/Timeline";
import { MediaLibrary } from "@/components/video-editor/MediaLibrary";
import { EffectsPanel } from "@/components/video-editor/EffectsPanel";
import { AspectRatioSelector } from "@/components/video-editor/AspectRatioSelector";
import { ExportModal } from "@/components/video-editor/ExportModal";
import { Button } from "@/components/ui/button";
import { Undo2, Redo2, Film } from "lucide-react";
import {
  ResizableHandle,
  ResizablePanel,
  ResizablePanelGroup,
} from "@/components/ui/resizable";

function VideoEditorContent() {
  return (
    <div className="h-screen flex flex-col bg-background overflow-hidden">
      <header className="h-14 border-b border-border flex items-center justify-between gap-4 px-4 bg-card flex-shrink-0">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <Film className="w-4 h-4 text-primary-foreground" />
            </div>
            <h1 className="text-lg font-semibold">ClipFlow</h1>
          </div>

          <div className="flex items-center gap-1">
            <Button size="icon" variant="ghost" data-testid="button-undo">
              <Undo2 className="w-4 h-4" />
            </Button>
            <Button size="icon" variant="ghost" data-testid="button-redo">
              <Redo2 className="w-4 h-4" />
            </Button>
          </div>
        </div>

        <AspectRatioSelector />

        <ExportModal />
      </header>

      <div className="flex-1 min-h-0">
        <ResizablePanelGroup direction="vertical">
          <ResizablePanel defaultSize={70} minSize={50}>
            <ResizablePanelGroup direction="horizontal">
              <ResizablePanel defaultSize={20} minSize={15} maxSize={30}>
                <div className="h-full border-r border-border bg-sidebar">
                  <MediaLibrary />
                </div>
              </ResizablePanel>

              <ResizableHandle withHandle />

              <ResizablePanel defaultSize={55} minSize={40}>
                <div className="h-full p-4">
                  <VideoPreview />
                </div>
              </ResizablePanel>

              <ResizableHandle withHandle />

              <ResizablePanel defaultSize={25} minSize={15} maxSize={35}>
                <div className="h-full border-l border-border bg-sidebar">
                  <EffectsPanel />
                </div>
              </ResizablePanel>
            </ResizablePanelGroup>
          </ResizablePanel>

          <ResizableHandle withHandle />

          <ResizablePanel defaultSize={30} minSize={20} maxSize={50}>
            <div className="h-full p-2 bg-muted/30">
              <Timeline />
            </div>
          </ResizablePanel>
        </ResizablePanelGroup>
      </div>
    </div>
  );
}

export default function VideoEditor() {
  return (
    <VideoProvider>
      <VideoEditorContent />
    </VideoProvider>
  );
}
