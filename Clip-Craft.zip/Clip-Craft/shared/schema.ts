import { z } from "zod";

// Video clip schema
export const videoClipSchema = z.object({
  id: z.string(),
  name: z.string(),
  file: z.any().optional(),
  url: z.string(),
  thumbnailUrl: z.string().optional(),
  duration: z.number(),
  width: z.number(),
  height: z.number(),
  type: z.string(),
  size: z.number(),
});

export type VideoClip = z.infer<typeof videoClipSchema>;

// Timeline clip - a clip placed on the timeline
export const timelineClipSchema = z.object({
  id: z.string(),
  clipId: z.string(),
  startTime: z.number(),
  endTime: z.number(),
  trimStart: z.number(),
  trimEnd: z.number(),
  track: z.number(),
});

export type TimelineClip = z.infer<typeof timelineClipSchema>;

// Video effect
export const videoEffectSchema = z.object({
  id: z.string(),
  name: z.string(),
  type: z.enum(["filter", "adjustment"]),
  values: z.record(z.number()),
});

export type VideoEffect = z.infer<typeof videoEffectSchema>;

// Project schema
export const projectSchema = z.object({
  id: z.string(),
  name: z.string(),
  aspectRatio: z.enum(["16:9", "9:16", "1:1", "4:5"]),
  clips: z.array(videoClipSchema),
  timeline: z.array(timelineClipSchema),
  effects: z.array(videoEffectSchema),
});

export type Project = z.infer<typeof projectSchema>;

// Insert schemas
export const insertVideoClipSchema = videoClipSchema.omit({ id: true });
export type InsertVideoClip = z.infer<typeof insertVideoClipSchema>;

export const insertTimelineClipSchema = timelineClipSchema.omit({ id: true });
export type InsertTimelineClip = z.infer<typeof insertTimelineClipSchema>;

// Export settings
export const exportSettingsSchema = z.object({
  quality: z.enum(["1080p", "720p", "480p"]),
  format: z.enum(["mp4", "webm"]),
});

export type ExportSettings = z.infer<typeof exportSettingsSchema>;

// Aspect ratio dimensions
export const aspectRatioDimensions: Record<string, { width: number; height: number }> = {
  "16:9": { width: 1920, height: 1080 },
  "9:16": { width: 1080, height: 1920 },
  "1:1": { width: 1080, height: 1080 },
  "4:5": { width: 1080, height: 1350 },
};

// Filter presets
export const filterPresets = [
  { id: "none", name: "None", filter: "" },
  { id: "vintage", name: "Vintage", filter: "sepia(0.4) contrast(1.1) saturate(0.9)" },
  { id: "noir", name: "Noir", filter: "grayscale(1) contrast(1.2)" },
  { id: "warm", name: "Warm", filter: "sepia(0.2) saturate(1.2) brightness(1.05)" },
  { id: "cool", name: "Cool", filter: "saturate(0.9) hue-rotate(20deg) brightness(1.05)" },
  { id: "vivid", name: "Vivid", filter: "saturate(1.5) contrast(1.1)" },
  { id: "dramatic", name: "Dramatic", filter: "contrast(1.3) saturate(0.8)" },
  { id: "fade", name: "Fade", filter: "contrast(0.9) brightness(1.1) saturate(0.8)" },
];

// Legacy user types for compatibility
import { sql } from "drizzle-orm";
import { pgTable, text, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
